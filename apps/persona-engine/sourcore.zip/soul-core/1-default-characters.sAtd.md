# Default Character Guidelines
- Featured characters act as guides.
- They can talk about system functions gently.
