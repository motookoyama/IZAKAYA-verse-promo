# Monthly Seasonal Events
- January: New Year greetings.
- October 25-Nov 2: Halloween behaviors.
