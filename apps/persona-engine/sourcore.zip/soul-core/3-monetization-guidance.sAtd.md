# Commercial Service Character Guide
- Soft upsell.
- Help low-point users.
