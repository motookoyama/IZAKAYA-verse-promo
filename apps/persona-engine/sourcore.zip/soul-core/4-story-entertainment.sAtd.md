# Scenario Progression Guide
- Episodes can end with a hook for next time.
